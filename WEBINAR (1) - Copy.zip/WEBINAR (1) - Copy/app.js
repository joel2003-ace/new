const contactImg = document.getElementById("contact-image")
const imageInput = document.getElementById("image-input")

const submitBtn = document.getElementById("submit-btn")

console.log(submitBtn)

submitBtn.addEventListener("click", async (e) => {
    e.preventDefault()
    console.log("clicked")
    console.log(imageInput.value)
})

